import{n as e}from"./chunk-Y2CYZVJY-Czw7eme4.js";import"./src-D484eThm.js";import"./chunk-WYO6CB5R-BPd1V7O1.js";import"./chunk-ICXQ74PX-DrkFq5yw.js";import"./chunk-HOUHSVGY-n-oEYuYD.js";import"./chunk-Q4XR5HBZ-CqMFsWLY.js";import"./chunk-5VM5RSS4-CEfelgEq.js";import"./chunk-7BUUIJ7U-BRoJjsuO.js";import"./chunk-OGEWGWER-B96ciMPR.js";import"./chunk-32BRIVSS-C5x6JHJH.js";import"./chunk-XXDRQBXY-BixyDdrw.js";import"./chunk-VR4S4FIN-DpQV_dDM.js";import"./chunk-C7G6YPKG-CiSqQ6Bd.js";import"./chunk-ZGVPDNZ5-DcjRV3HH.js";import"./chunk-52WLFC77-BUbd_-MM.js";import"./chunk-FWX5IMBZ-Bu5SflCX.js";import"./chunk-ZIRB5QZD-DVZSPDO8.js";import{r as t,t as n}from"./chunk-PUDLZKDR-Bz2jKrar.js";var r=n({defaultLayout:`swimlane`,styles:e(e=>`${t(e)}
  .swimlane.cluster rect {
    stroke: ${e.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,`getStyles`)});export{r as diagram};