import{n as e}from"./chunk-Y2CYZVJY-wHqa-fgR.js";import"./src-BNUHgv3M.js";import"./chunk-WYO6CB5R-DqX2HiQr.js";import"./chunk-ICXQ74PX-BA8hFySJ.js";import"./chunk-HOUHSVGY-Y2diBPER.js";import"./chunk-Q4XR5HBZ-SofgO5We.js";import"./chunk-5VM5RSS4-C809U-98.js";import"./chunk-7BUUIJ7U-DBVXy_ev.js";import"./chunk-OGEWGWER-CJG7T_nq.js";import"./chunk-32BRIVSS-DNuNShHj.js";import"./chunk-XXDRQBXY-Q4xapNNI.js";import"./chunk-VR4S4FIN-CzmWTQk7.js";import"./chunk-C7G6YPKG-D8wBDCFD.js";import"./chunk-ZGVPDNZ5-C8Nr7_wD.js";import"./chunk-52WLFC77-DfrlhKWX.js";import"./chunk-FWX5IMBZ-BX6ecd36.js";import"./chunk-ZIRB5QZD-CqQ3RO4e.js";import{r as t,t as n}from"./chunk-PUDLZKDR-84rvlLDD.js";var r=n({defaultLayout:`swimlane`,styles:e(e=>`${t(e)}
  .swimlane.cluster rect {
    stroke: ${e.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,`getStyles`)});export{r as diagram};