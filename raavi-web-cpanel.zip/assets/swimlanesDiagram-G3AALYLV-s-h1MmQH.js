import{n as e}from"./chunk-Y2CYZVJY-Czw7eme4.js";import"./src-D484eThm.js";import"./chunk-WYO6CB5R-BrXO77YN.js";import"./chunk-ICXQ74PX-jShwyEMT.js";import"./chunk-HOUHSVGY-LMlIrO_H.js";import"./chunk-Q4XR5HBZ-CLfd3hZN.js";import"./chunk-5VM5RSS4-CEfelgEq.js";import"./chunk-7BUUIJ7U-BRoJjsuO.js";import"./chunk-OGEWGWER-D8ZPL40d.js";import"./chunk-32BRIVSS-BKRCaRP_.js";import"./chunk-XXDRQBXY-BixyDdrw.js";import"./chunk-VR4S4FIN-Cbn-e8Ne.js";import"./chunk-C7G6YPKG-BFyUinOU.js";import"./chunk-ZGVPDNZ5-BzAl7CIA.js";import"./chunk-52WLFC77-CvwNMyvE.js";import"./chunk-FWX5IMBZ-D70fFdgW.js";import"./chunk-ZIRB5QZD-DVZSPDO8.js";import{r as t,t as n}from"./chunk-PUDLZKDR-zZo9nGbH.js";var r=n({defaultLayout:`swimlane`,styles:e(e=>`${t(e)}
  .swimlane.cluster rect {
    stroke: ${e.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,`getStyles`)});export{r as diagram};