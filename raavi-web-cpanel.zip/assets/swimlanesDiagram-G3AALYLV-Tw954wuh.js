import{n as e}from"./chunk-Y2CYZVJY-CWQMkYLE.js";import"./src-B7Pk8878.js";import"./chunk-WYO6CB5R-fZBLmScW.js";import"./chunk-ICXQ74PX-zJCbMZAk.js";import"./chunk-HOUHSVGY-DUw6xCAp.js";import"./chunk-Q4XR5HBZ-C_-q6XC8.js";import"./chunk-5VM5RSS4-1Yz2hDgo.js";import"./chunk-7BUUIJ7U-Ht7wQIco.js";import"./chunk-OGEWGWER-uiWCyltx.js";import"./chunk-32BRIVSS-DAm6K3qB.js";import"./chunk-XXDRQBXY-D_kE5dQO.js";import"./chunk-VR4S4FIN-BN1qrt3Z.js";import"./chunk-C7G6YPKG-keaFSAX6.js";import"./chunk-ZGVPDNZ5-BHuOlgFr.js";import"./chunk-52WLFC77-CrDDtNbd.js";import"./chunk-FWX5IMBZ-B3qRUB0E.js";import"./chunk-ZIRB5QZD-BrSouI7f.js";import{r as t,t as n}from"./chunk-PUDLZKDR-DReedxp8.js";var r=n({defaultLayout:`swimlane`,styles:e(e=>`${t(e)}
  .swimlane.cluster rect {
    stroke: ${e.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,`getStyles`)});export{r as diagram};