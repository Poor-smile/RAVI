import{n as e}from"./chunk-Y2CYZVJY-C9Cn5itF.js";import"./src-BcHJJKHR.js";import"./chunk-WYO6CB5R-BeCU7qYh.js";import"./chunk-ICXQ74PX-ZcQ9K6KA.js";import"./chunk-HOUHSVGY-DbfBQ9Mh.js";import"./chunk-Q4XR5HBZ-C7tN3nR8.js";import"./chunk-5VM5RSS4-d1RpFWpM.js";import"./chunk-7BUUIJ7U-DpV4nbQC.js";import"./chunk-OGEWGWER-T-pV2SQF.js";import"./chunk-32BRIVSS-BJfz_Nvv.js";import"./chunk-XXDRQBXY-Ct5fcPRK.js";import"./chunk-VR4S4FIN-S5_NTOnd.js";import"./chunk-C7G6YPKG-COZLzZFl.js";import"./chunk-ZGVPDNZ5-vtADcFUk.js";import"./chunk-52WLFC77-DIlsloIp.js";import"./chunk-FWX5IMBZ-CqGPdMa_.js";import"./chunk-ZIRB5QZD-B3xT9WBb.js";import{r as t,t as n}from"./chunk-PUDLZKDR-DRyMgV9r.js";var r=n({defaultLayout:`swimlane`,styles:e(e=>`${t(e)}
  .swimlane.cluster rect {
    stroke: ${e.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,`getStyles`)});export{r as diagram};