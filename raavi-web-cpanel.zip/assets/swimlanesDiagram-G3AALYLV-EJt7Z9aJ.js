import{n as e}from"./chunk-Y2CYZVJY-wHqa-fgR.js";import"./src-BNUHgv3M.js";import"./chunk-WYO6CB5R-9F5itOXX.js";import"./chunk-ICXQ74PX-Zi68Hgji.js";import"./chunk-HOUHSVGY-xpMlRoYc.js";import"./chunk-Q4XR5HBZ-BLH3wI7U.js";import"./chunk-5VM5RSS4-C809U-98.js";import"./chunk-7BUUIJ7U-DBVXy_ev.js";import"./chunk-OGEWGWER-BWs44Yef.js";import"./chunk-32BRIVSS-_OuhQ4gE.js";import"./chunk-XXDRQBXY-Q4xapNNI.js";import"./chunk-VR4S4FIN-lpj3Fbjr.js";import"./chunk-C7G6YPKG-D_VNX1hQ.js";import"./chunk-ZGVPDNZ5-BjFHSjV7.js";import"./chunk-52WLFC77-CynK2CPf.js";import"./chunk-FWX5IMBZ-B6kmDMSn.js";import"./chunk-ZIRB5QZD-CqQ3RO4e.js";import{r as t,t as n}from"./chunk-PUDLZKDR-BsLzo3gN.js";var r=n({defaultLayout:`swimlane`,styles:e(e=>`${t(e)}
  .swimlane.cluster rect {
    stroke: ${e.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`,`getStyles`)});export{r as diagram};