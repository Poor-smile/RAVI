const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/mermaid.core-Ed2OIIdW.js","assets/index-Bu5dm5Uv.js","assets/rolldown-runtime-S-ySWqyJ.js","assets/framework-CXnKph_e.js","assets/chunk-HOUHSVGY-LMlIrO_H.js","assets/src-D484eThm.js","assets/chunk-Y2CYZVJY-Czw7eme4.js","assets/chunk-WYO6CB5R-BrXO77YN.js","assets/chunk-ICXQ74PX-jShwyEMT.js","assets/dist-jjmZm6rp.js","assets/chunk-Q4XR5HBZ-CLfd3hZN.js","assets/chunk-52WLFC77-CvwNMyvE.js","assets/line-DY9bghcJ.js","assets/path-sMK4d_s9.js","assets/array-BNor45A1.js","assets/chunk-7BUUIJ7U-BRoJjsuO.js","assets/chunk-C7G6YPKG-BFyUinOU.js","assets/chunk-OGEWGWER-D8ZPL40d.js","assets/chunk-ZGVPDNZ5-BzAl7CIA.js","assets/rough.esm-BQX0AvsS.js","assets/chunk-FWX5IMBZ-D70fFdgW.js","assets/chunk-VAUOI2AC-BEDq5Xkb.js","assets/chunk-ZIRB5QZD-DVZSPDO8.js"])))=>i.map(i=>d[i]);
import{r as e}from"./rolldown-runtime-S-ySWqyJ.js";import{i as t,r as n}from"./framework-CXnKph_e.js";import{t as r}from"./index-Bu5dm5Uv.js";var i=e(t(),1),a=(...e)=>e.filter((e,t,n)=>!!e&&e.trim()!==``&&n.indexOf(e)===t).join(` `).trim(),o=e=>e.replace(/([a-z0-9])([A-Z])/g,`$1-$2`).toLowerCase(),s=e=>e.replace(/^([A-Z])|[\s-_]+(\w)/g,(e,t,n)=>n?n.toUpperCase():t.toLowerCase()),c=e=>{let t=s(e);return t.charAt(0).toUpperCase()+t.slice(1)},l={xmlns:`http://www.w3.org/2000/svg`,width:24,height:24,viewBox:`0 0 24 24`,fill:`none`,stroke:`currentColor`,strokeWidth:2,strokeLinecap:`round`,strokeLinejoin:`round`},u=e=>{for(let t in e)if(t.startsWith(`aria-`)||t===`role`||t===`title`)return!0;return!1},d=(0,i.createContext)({}),f=()=>(0,i.useContext)(d),p=(0,i.forwardRef)(({color:e,size:t,strokeWidth:n,absoluteStrokeWidth:r,className:o=``,children:s,iconNode:c,...d},p)=>{let{size:m=24,strokeWidth:h=2,absoluteStrokeWidth:g=!1,color:_=`currentColor`,className:v=``}=f()??{},y=r??g?Number(n??h)*24/Number(t??m):n??h;return(0,i.createElement)(`svg`,{ref:p,...l,width:t??m??l.width,height:t??m??l.height,stroke:e??_,strokeWidth:y,className:a(`lucide`,v,o),...!s&&!u(d)&&{"aria-hidden":`true`},...d},[...c.map(([e,t])=>(0,i.createElement)(e,t)),...Array.isArray(s)?s:[s]])}),m=(e,t)=>{let n=(0,i.forwardRef)(({className:n,...r},s)=>(0,i.createElement)(p,{ref:s,iconNode:t,className:a(`lucide-${o(c(e))}`,`lucide-${e}`,n),...r}));return n.displayName=c(e),n},h=m(`book-open`,[[`path`,{d:`M12 5v16`,key:`1f6ucr`}],[`path`,{d:`M20.001 19A2 2 0 0022 17V5a2 2 0 00-1.999-2L16 3.002A5 5 0 0012 5a5 5 0 00-4-2H4a2 2 0 00-2 2v12a2 2 0 001.999 2H8a5 5 0 014 2 5 5 0 014-2z`,key:`1fyvmf`}]]),g=m(`check`,[[`path`,{d:`M20 6 9 17l-5-5`,key:`1gmf2c`}]]),_=m(`chevron-down`,[[`path`,{d:`m6 9 6 6 6-6`,key:`qrunsl`}]]),v=m(`clock-3`,[[`circle`,{cx:`12`,cy:`12`,r:`10`,key:`1mglay`}],[`path`,{d:`M12 6v6h4`,key:`135r8i`}]]),y=m(`code-xml`,[[`path`,{d:`m18 16 4-4-4-4`,key:`1inbqp`}],[`path`,{d:`m6 8-4 4 4 4`,key:`15zrgr`}],[`path`,{d:`m14.5 4-5 16`,key:`e7oirm`}]]),ee=m(`copy`,[[`rect`,{width:`14`,height:`14`,x:`8`,y:`8`,rx:`2`,ry:`2`,key:`17jyea`}],[`path`,{d:`M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2`,key:`zix9uf`}]]),te=m(`eye`,[[`path`,{d:`M2.062 12.348a1 1 0 0 1 0-.696 10.75 10.75 0 0 1 19.876 0 1 1 0 0 1 0 .696 10.75 10.75 0 0 1-19.876 0`,key:`1nclc0`}],[`circle`,{cx:`12`,cy:`12`,r:`3`,key:`1v7zrd`}]]),b=m(`hand`,[[`path`,{d:`M18 11V6a2 2 0 0 0-2-2a2 2 0 0 0-2 2`,key:`1fvzgz`}],[`path`,{d:`M14 10V4a2 2 0 0 0-2-2a2 2 0 0 0-2 2v2`,key:`1kc0my`}],[`path`,{d:`M10 10.5V6a2 2 0 0 0-2-2a2 2 0 0 0-2 2v8`,key:`10h0bg`}],[`path`,{d:`M18 8a2 2 0 1 1 4 0v6a8 8 0 0 1-8 8h-2c-2.8 0-4.5-.86-5.99-2.34l-3.6-3.6a2 2 0 0 1 2.83-2.82L7 15`,key:`1s1gnw`}]]),x=m(`library`,[[`path`,{d:`m16 6 4 14`,key:`ji33uf`}],[`path`,{d:`M12 6v14`,key:`1n7gus`}],[`path`,{d:`M8 8v12`,key:`1gg7y9`}],[`path`,{d:`M4 4v16`,key:`6qkkli`}]]),S=m(`loader-circle`,[[`path`,{d:`M21 12a9 9 0 1 1-6.219-8.56`,key:`13zald`}]]),C=m(`maximize-2`,[[`path`,{d:`M15 3h6v6`,key:`1q9fwt`}],[`path`,{d:`m21 3-7 7`,key:`1l2asr`}],[`path`,{d:`m3 21 7-7`,key:`tjx5ai`}],[`path`,{d:`M9 21H3v-6`,key:`wtvkvv`}]]),ne=m(`minimize-2`,[[`path`,{d:`m14 10 7-7`,key:`oa77jy`}],[`path`,{d:`M20 10h-6V4`,key:`mjg0md`}],[`path`,{d:`m3 21 7-7`,key:`tjx5ai`}],[`path`,{d:`M4 14h6v6`,key:`rmj7iw`}]]),re=m(`plus`,[[`path`,{d:`M5 12h14`,key:`1ays0h`}],[`path`,{d:`M12 5v14`,key:`s699le`}]]),ie=m(`redo-2`,[[`path`,{d:`m15 14 5-5-5-5`,key:`12vg1m`}],[`path`,{d:`M20 9H9.5A5.5 5.5 0 0 0 4 14.5A5.5 5.5 0 0 0 9.5 20H13`,key:`6uklza`}]]),ae=m(`scan`,[[`path`,{d:`M3 7V5a2 2 0 0 1 2-2h2`,key:`aa7l1z`}],[`path`,{d:`M17 3h2a2 2 0 0 1 2 2v2`,key:`4qcy5o`}],[`path`,{d:`M21 17v2a2 2 0 0 1-2 2h-2`,key:`6vwrx8`}],[`path`,{d:`M7 21H5a2 2 0 0 1-2-2v-2`,key:`ioqczr`}]]),w=m(`search`,[[`path`,{d:`m21 21-4.34-4.34`,key:`14j7rj`}],[`circle`,{cx:`11`,cy:`11`,r:`8`,key:`4ej97u`}]]),oe=m(`trash-2`,[[`path`,{d:`M10 11v6`,key:`nco0om`}],[`path`,{d:`M14 11v6`,key:`outv1u`}],[`path`,{d:`M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6`,key:`miytrc`}],[`path`,{d:`M3 6h18`,key:`d0wm0j`}],[`path`,{d:`M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2`,key:`e791ji`}]]),T=m(`triangle-alert`,[[`path`,{d:`m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3`,key:`wmoenq`}],[`path`,{d:`M12 9v4`,key:`juzpu7`}],[`path`,{d:`M12 17h.01`,key:`p32p05`}]]),E=m(`undo-2`,[[`path`,{d:`M9 14 4 9l5-5`,key:`102s5s`}],[`path`,{d:`M4 9h10.5a5.5 5.5 0 0 1 5.5 5.5a5.5 5.5 0 0 1-5.5 5.5H11`,key:`f3b9sd`}]]),D=m(`x`,[[`path`,{d:`M18 6 6 18`,key:`1bl5f8`}],[`path`,{d:`m6 6 12 12`,key:`d8bk6v`}]]),se=m(`zoom-out`,[[`circle`,{cx:`11`,cy:`11`,r:`8`,key:`4ej97u`}],[`line`,{x1:`21`,x2:`16.65`,y1:`21`,y2:`16.65`,key:`13gj7c`}],[`line`,{x1:`8`,x2:`14`,y1:`11`,y2:`11`,key:`durymu`}]]),ce=m(`zoom-in`,[[`circle`,{cx:`11`,cy:`11`,r:`8`,key:`4ej97u`}],[`line`,{x1:`21`,x2:`16.65`,y1:`21`,y2:`16.65`,key:`13gj7c`}],[`line`,{x1:`11`,x2:`11`,y1:`8`,y2:`14`,key:`1vmskp`}],[`line`,{x1:`8`,x2:`14`,y1:`11`,y2:`11`,key:`durymu`}]]),O=class extends Error{constructor(e,t,n){super(e),this.name=`PersianMermaidInputError`,this.line=t,this.suggestion=n}},le=`۰۱۲۳۴۵۶۷۸۹`,ue=`٠١٢٣٤٥٦٧٨٩`,de=/[\u064B-\u065F\u0670\u06D6-\u06ED]/gu;function k(e){return e.replace(/[۰-۹]/gu,e=>String(le.indexOf(e))).replace(/[٠-٩]/gu,e=>String(ue.indexOf(e))).replace(/٫/gu,`.`)}function A(e){return k(e).normalize(`NFKC`).replace(de,``).replace(/ي/gu,`ی`).replace(/ك/gu,`ک`).replace(/[‌\s]+/gu,` `).trim().toLocaleLowerCase(`fa-IR`)}function j(e){let t=e.trimStart(),n=(t.startsWith(`---`)?t.replace(/^---\s*\r?\n[\s\S]*?\r?\n---\s*\r?\n/u,``):t).split(/\r?\n/u,1)[0]?.trim()??``;return/^(?:flowchart|graph)\b/iu.test(n)?`flowchart`:/^sequenceDiagram\b/iu.test(n)?`sequence`:/^classDiagram\b/iu.test(n)?`class`:/^stateDiagram(?:-v2)?\b/iu.test(n)?`state`:/^erDiagram\b/iu.test(n)?`er`:/^requirementDiagram\b/iu.test(n)?`requirement`:/^architecture-beta\b/iu.test(n)?`architecture`:/^C4(?:Context|Container|Component|Dynamic|Deployment)\b/iu.test(n)?`c4`:/^mindmap\b/iu.test(n)?`mindmap`:/^timeline\b/iu.test(n)?`timeline`:/^pie\b/iu.test(n)?`pie`:/^sankey(?:-beta)?\b/iu.test(n)?`sankey`:/^journey\b/iu.test(n)?`journey`:/^quadrantChart\b/iu.test(n)?`quadrant`:/^xychart(?:-beta)?\b/iu.test(n)?`xychart`:/^gantt\b/iu.test(n)?`gantt`:/^kanban\b/iu.test(n)?`kanban`:/^gitGraph\b/iu.test(n)?`gitgraph`:/^swimlane-beta\b/iu.test(n)?`swimlane`:/^block(?:-beta)?\b/iu.test(n)?`block`:/^packet(?:-beta)?\b/iu.test(n)?`packet`:/^radar-beta\b/iu.test(n)?`radar`:/^eventmodeling\b/iu.test(n)?`eventmodeling`:/^treemap(?:-beta)?\b/iu.test(n)?`treemap`:/^venn-beta\b/iu.test(n)?`venn`:/^ishikawa(?:-beta)?\b/iu.test(n)?`ishikawa`:/^wardley-beta\b/iu.test(n)?`wardley`:/^cynefin-beta\b/iu.test(n)?`cynefin`:/^treeView-beta\b/iu.test(n)?`treeview`:`other`}function M(e){let t=[],n=``,r=!1;for(let i=0;i<e.length;i+=1){let a=e[i];if(a===`"`){r&&e[i+1]===`"`?(n+=`"`,i+=1):r=!r;continue}if(!r&&(a===`,`||a===`،`)){t.push(n.trim()),n=``;continue}n+=a}return r?null:(t.push(n.trim()),t)}function N(e){return e.replace(/\[([^\]]*)\]/gu,(e,t)=>/[۰-۹٠-٩٫]/u.test(t)?`[${k(t)}]`:e)}function P(e){let t=0;for(;t<e.length&&!e[t].trim();)t+=1;if(e[t]?.trim()!==`---`)return t;for(t+=1;t<e.length&&e[t].trim()!==`---`;)t+=1;for(t<e.length&&(t+=1);t<e.length&&!e[t].trim();)t+=1;return t}function F(e,t){let n=e.split(/\r?\n/u),r=P(n);return n.map((e,n)=>{if(n<=r)return e;if(t===`pie`){let t=e.lastIndexOf(`:`);return t<0?e:`${e.slice(0,t+1)}${k(e.slice(t+1))}`}if(t===`quadrant`)return N(e);if(t===`xychart`){let t=N(e);return/^\s*y-axis\b/iu.test(t)?t.replace(/([۰-۹٠-٩\d]+(?:[٫.]?[۰-۹٠-٩\d]+)?)\s*-->\s*([۰-۹٠-٩\d]+(?:[٫.]?[۰-۹٠-٩\d]+)?)/u,e=>k(e)):t}if(t===`journey`){let t=e.split(`:`);return t.length<3?e:(t[1]=k(t[1]),t.join(`:`))}if(t===`gantt`){let t=e.indexOf(`:`);return t<0?e:`${e.slice(0,t+1)}${k(e.slice(t+1))}`}if(t===`packet`)return e.replace(/^(\s*)(\+?[۰-۹٠-٩\d]+)(?:\s*-\s*([۰-۹٠-٩\d]+))?(\s*:)/u,(e,t,n,r,i)=>`${t}${k(n)}${r?`-${k(r)}`:``}${i}`);if(t===`radar`)return/^\s*(?:max|min|ticks)\b/iu.test(e)?k(e):e.replace(/\{([^}]*)\}/gu,(e,t)=>/[۰-۹٠-٩٫]/u.test(t)?`{${k(t)}}`:e);if(t===`treemap`||t===`venn`){let t=e.lastIndexOf(`:`);return t<0?e:`${e.slice(0,t+1)}${k(e.slice(t+1))}`}if(t===`wardley`){let t=N(e);return/^\s*evolve\b/iu.test(t)?k(t):t}return t===`eventmodeling`?e.replace(/^(\s*(?:tf|timeframe|rf|resetframe)\s+)([۰-۹٠-٩\d]+)/iu,(e,t,n)=>`${t}${k(n)}`):t===`block`?e.replace(/^(\s*columns\s+)([۰-۹٠-٩\d]+)/iu,(e,t,n)=>`${t}${k(n)}`):e}).join(`
`)}function I(e){let t=new Map;for(let n of e.matchAll(/^%% raavi-label:([A-Za-z0-9_]+):([^\r\n]+)$/gmu))try{t.set(n[1],decodeURIComponent(n[2]))}catch{}return t}function L(e){let t=e.split(/\r?\n/u),n=P(t),r=new Map,i=new Map,a=0,o=e=>{let t=i.get(e);if(t)return t;a+=1;let n=`RAAVI_FA_${a}`;return i.set(e,n),r.set(n,e),n};return{code:t.map((e,t)=>{if(t<=n||!e.trim()||e.trimStart().startsWith(`%%`))return e;let r=(t+1).toLocaleString(`fa-IR`),i=M(e);if(!i||i.length!==3)throw new O(`ردیف ${r} قابل خواندن نیست.`,t+1,`هر مسیر باید سه بخش داشته باشد: مبدأ، مقصد و مقدار.`);let[a,s,c]=i;if(!a||!s)throw new O(`مبدأ یا مقصد در ردیف ${r} خالی است.`,t+1,`برای هر مسیر، هر دو خانهٔ مبدأ و مقصد را کامل کنید.`);let l=k(c).trim(),u=Number(l);if(!l||!Number.isFinite(u)||u<0)throw new O(`مقدار ردیف ${r} معتبر نیست.`,t+1,`یک عدد صفر یا بزرگ‌تر وارد کنید؛ اعداد فارسی نیز پذیرفته می‌شوند.`);return`${o(a)},${o(s)},${l}`}).join(`
`),kind:`sankey`,labelMap:r}}function R(e){let t=j(e),n=I(e);if(t===`sankey`){let t=L(e);for(let[e,r]of n)t.labelMap.set(e,r);return t}return{code:F(e,t),kind:t,labelMap:n}}var z=`flowchart RL
    start([شروع]) --> review{نیاز به بازبینی؟}
    review -->|بله| edit[ویرایش سند]
    edit --> review
    review -->|خیر| done([انتشار])`,B=[{id:`flowchart`,category:`پایه`,title:`فلوچارت`,description:`نمایش مسیر، تصمیم و فرایند.`,docsUrl:`https://mermaid.js.org/syntax/flowchart.html`,code:z},{id:`sequence`,category:`پایه`,title:`توالی`,description:`گفت‌وگوی زمان‌مند میان نقش‌ها.`,docsUrl:`https://mermaid.js.org/syntax/sequenceDiagram.html`,code:`sequenceDiagram
    participant کاربر
    participant راوی
    کاربر->>راوی: فایل را باز کن
    راوی-->>کاربر: پیش‌نمایش آماده است`},{id:`class`,category:`مهندسی`,title:`کلاس`,description:`ساختار کلاس‌ها و رابطهٔ میان آن‌ها.`,docsUrl:`https://mermaid.js.org/syntax/classDiagram.html`,code:`classDiagram
    class سند {
      +String نام
      +ذخیره()
    }
    class نمودار {
      +String کد
      +رندر()
    }
    سند "1" *-- "*" نمودار`},{id:`state`,category:`مهندسی`,title:`حالت`,description:`چرخهٔ حالت‌های یک فرایند.`,docsUrl:`https://mermaid.js.org/syntax/stateDiagram.html`,code:`stateDiagram-v2
    [*] --> پیش_نویس
    پیش_نویس --> بازبینی
    بازبینی --> منتشر_شده
    بازبینی --> پیش_نویس`},{id:`er`,category:`مهندسی`,title:`رابطهٔ موجودیت`,description:`مدل داده و نسبت موجودیت‌ها.`,docsUrl:`https://mermaid.js.org/syntax/entityRelationshipDiagram.html`,code:`erDiagram
    DOCUMENT ||--o{ DIAGRAM : contains
    DOCUMENT {
      string name
      string format
    }
    DIAGRAM {
      string source
      string theme
    }`},{id:`requirement`,category:`مهندسی`,title:`نیازمندی`,description:`ردیابی نیازمندی و اجزای سیستم.`,docsUrl:`https://mermaid.js.org/syntax/requirementDiagram.html`,code:`requirementDiagram
    requirement readability {
      id: 1
      text: "متن و نمودار خوانا باشند"
      risk: low
      verifymethod: test
    }
    element preview {
      type: component
    }
    preview - satisfies -> readability`},{id:`architecture`,category:`مهندسی`,title:`معماری`,description:`سرویس‌ها، گروه‌ها و اتصال‌های معماری.`,docsUrl:`https://mermaid.js.org/syntax/architecture.html`,code:`architecture-beta
    group app(cloud)["راوی"]
    service editor(server)["ویرایشگر"] in app
    service preview(internet)["پیش نمایش"] in app
    editor:R -- L:preview`},{id:`c4`,category:`مهندسی`,title:`C4`,description:`نمای زمینهٔ سامانه و کاربران.`,docsUrl:`https://mermaid.js.org/syntax/c4.html`,code:`C4Context
    title زمینه سامانه راوی
    Person(reader, "خواننده", "مطالعه و حاشیه نویسی")
    System(raavi, "راوی", "ویرایشگر Markdown")
    Rel(reader, raavi, "استفاده می کند")`},{id:`gantt`,category:`برنامه‌ریزی`,title:`گانت`,description:`زمان‌بندی کارها و نقاط عطف.`,docsUrl:`https://mermaid.js.org/syntax/gantt.html`,code:`gantt
    title برنامه انتشار
    dateFormat YYYY-MM-DD
    section طراحی
    نمونه اولیه :done, a1, 2026-07-01, 5d
    section توسعه
    پیاده سازی :active, a2, after a1, 8d`},{id:`timeline`,category:`برنامه‌ریزی`,title:`خط زمانی`,description:`رویدادها در امتداد زمان.`,docsUrl:`https://mermaid.js.org/syntax/timeline.html`,code:`timeline
    title مسیر سند
    پیش نویس : نوشتن
    بازبینی : دریافت نظر
    انتشار : اشتراک فایل`},{id:`kanban`,category:`برنامه‌ریزی`,title:`کانبان`,description:`وضعیت کارها در ستون‌های جریان کار.`,docsUrl:`https://mermaid.js.org/syntax/kanban.html`,code:`kanban
    todo[برای انجام]
      task1[طراحی نمودار]
    doing[در حال انجام]
      task2[بازبینی متن]
    done[انجام شده]
      task3[ساخت فایل]`},{id:`gitgraph`,category:`برنامه‌ریزی`,title:`شاخه‌های Git`,description:`شاخه، ادغام و تاریخچهٔ نسخه‌ها.`,docsUrl:`https://mermaid.js.org/syntax/gitgraph.html`,code:`gitGraph
    commit id: "شروع"
    branch feature
    checkout feature
    commit id: "نمودار"
    checkout main
    merge feature id: "انتشار"`},{id:`pie`,category:`داده`,title:`دایره‌ای`,description:`سهم چند مقدار از کل.`,docsUrl:`https://mermaid.js.org/syntax/pie.html`,code:`pie showData
    title زمان مطالعه
    "مطالعه" : 55
    "یادداشت" : 25
    "بازبینی" : 20`},{id:`xychart`,category:`داده`,title:`نمودار XY`,description:`مقایسهٔ داده‌های عددی روی محور.`,docsUrl:`https://mermaid.js.org/syntax/xyChart.html`,code:`xychart-beta
    title "رشد نسخه ها"
    x-axis [1, 2, 3, 4, 5]
    y-axis "تغییرات" 0 --> 20
    line [3, 7, 9, 14, 18]`},{id:`sankey`,category:`داده`,title:`سنکی`,description:`جریان مقدار میان مبدأ و مقصد.`,docsUrl:`https://mermaid.js.org/syntax/sankey.html`,code:`sankey-beta

ورودی،مطالعه،۸
ورودی،ویرایش،۵
ویرایش،انتشار،۴
مطالعه،یادداشت،۳`},{id:`mindmap`,category:`ایده`,title:`نقشهٔ ذهنی`,description:`شاخه‌بندی موضوع‌ها و ایده‌ها.`,docsUrl:`https://mermaid.js.org/syntax/mindmap.html`,code:`mindmap
  root((راوی))
    مطالعه
      پیش نمایش
      فهرست
    نوشتن
      Markdown
      نمودار`},{id:`journey`,category:`ایده`,title:`سفر کاربر`,description:`مراحل تجربه و میزان رضایت.`,docsUrl:`https://mermaid.js.org/syntax/userJourney.html`,code:`journey
    title ساخت یک سند
    section شروع
      باز کردن فایل: 5: کاربر
      ویرایش متن: 4: کاربر
    section پایان
      افزودن نمودار: 5: کاربر
      ذخیره نسخه: 5: کاربر`},{id:`quadrant`,category:`داده`,title:`چهارخانه`,description:`جای‌گذاری گزینه‌ها روی دو محور.`,docsUrl:`https://mermaid.js.org/syntax/quadrantChart.html`,code:`quadrantChart
    title اولویت قابلیت ها
    x-axis کم اثر --> پراثر
    y-axis دشوار --> آسان
    "جستجو": [0.7, 0.8]
    "نمودار": [0.9, 0.6]
    "چاپ": [0.5, 0.7]`},{id:`swimlane`,category:`پایه`,title:`مسیر مسئولیت`,description:`فرایند در خط‌های جداگانهٔ افراد، تیم‌ها یا سامانه‌ها.`,docsUrl:`https://mermaid.js.org/syntax/swimlanes.html`,code:`swimlane-beta RL
    accTitle: رسیدگی به درخواست
    subgraph customer["مشتری"]
        request(["ثبت درخواست"])
    end
    subgraph support["پشتیبانی"]
        review["بررسی درخواست"]
        answer["ارسال پاسخ"]
    end
    request -->|ارجاع| review
    review -->|تأیید| answer`},{id:`block`,category:`مهندسی`,title:`نمودار بلوکی`,description:`اجزای سامانه با کنترل ستون، پهنا، شکل و اتصال.`,docsUrl:`https://mermaid.js.org/syntax/block.html`,code:`block-beta
    columns 3
    editor["ویرایشگر"]
    preview["پیش‌نمایش"]
    storage[("ذخیره‌سازی")]
    editor -->|به‌روزرسانی| preview
    preview -->|ثبت| storage`},{id:`packet`,category:`مهندسی`,title:`ساختار بسته`,description:`جای فیلدها در یک بستهٔ داده بر اساس تعداد بیت.`,docsUrl:`https://mermaid.js.org/syntax/packet.html`,code:`---
config:
  packet:
    bitsPerRow: 32
---
packet
    title بستهٔ داده
    +4: "نسخه"
    +4: "نوع"
    +8: "طول"
    +16: "داده"`},{id:`radar`,category:`داده`,title:`نمودار رادار`,description:`مقایسهٔ چند سری روی مجموعه‌ای از معیارهای مشترک.`,docsUrl:`https://mermaid.js.org/syntax/radar.html`,code:`radar-beta
    title توانمندی تیم
    axis speed["سرعت"], quality["کیفیت"], learning["یادگیری"]
    curve now["اکنون"] { speed: 70, quality: 80, learning: 60 }
    curve goal["هدف"] { speed: 90, quality: 90, learning: 85 }
    showLegend true
    min 0
    max 100
    graticule polygon
    ticks 5`},{id:`eventmodeling`,category:`مهندسی`,title:`مدل‌سازی رویداد`,description:`جریان زمانی رابط، فرمان، رویداد و مدل‌های سامانه.`,docsUrl:`https://mermaid.js.org/syntax/eventModeling.html`,code:`---
title: "جریان ثبت سفارش"
---
eventmodeling
    tf 01 ui SHOP.CART
    tf 02 cmd SHOP.SUBMIT
    tf 03 evt SHOP.CREATED
%% raavi-label:SHOP:%D9%81%D8%B1%D9%88%D8%B4%DA%AF%D8%A7%D9%87
%% raavi-label:CART:%D8%B5%D9%81%D8%AD%D9%87%D9%94%20%D8%B3%D8%A8%D8%AF
%% raavi-label:SUBMIT:%D8%AB%D8%A8%D8%AA%20%D8%B3%D9%81%D8%A7%D8%B1%D8%B4
%% raavi-label:CREATED:%D8%B3%D9%81%D8%A7%D8%B1%D8%B4%20%D8%AB%D8%A8%D8%AA%20%D8%B4%D8%AF`},{id:`treemap`,category:`داده`,title:`نقشهٔ درختی مساحتی`,description:`نمایش سهم بخش‌ها در یک ساختار سلسله‌مراتبی.`,docsUrl:`https://mermaid.js.org/syntax/treemap.html`,code:`---
title: "سهم قابلیت‌ها"
config:
  treemap:
    showValues: true
---
treemap-beta
  "محصول"
    "ویرایشگر": 40
    "مطالعه": 35
    "نمودار": 25`},{id:`venn`,category:`داده`,title:`نمودار ون`,description:`مجموعه‌ها، هم‌پوشانی‌ها و اندازهٔ هر ناحیه.`,docsUrl:`https://mermaid.js.org/syntax/venn.html`,code:`venn-beta
    title هم‌پوشانی مهارت‌ها
    set technical["فنی"]: 12
    set product["محصول"]: 10
    union technical,product["مهارت مشترک"]: 4`},{id:`ishikawa`,category:`ایده`,title:`علت و معلول (ایشیکاوا)`,description:`دسته‌بندی علت‌های اصلی، علت‌ها و زیرعلت‌های یک مسئله.`,docsUrl:`https://mermaid.js.org/syntax/ishikawa.html`,code:`ishikawa
  کندی انتشار
    فرایند
      بازبینی دیرهنگام
        تأیید دستی
    ابزار
      آزمون ناکافی
        پوشش کم`},{id:`wardley`,category:`ایده`,title:`نقشهٔ واردلی`,description:`زنجیرهٔ ارزش بر اساس دیده‌شدن، بلوغ و وابستگی.`,docsUrl:`https://mermaid.js.org/syntax/wardley.html`,code:`wardley-beta
    title زنجیرهٔ ارزش راوی
    size [1100, 700]
    anchor "کاربر" [0.95, 0.65]
    component "راوی" [0.8, 0.55] (build)
    component "ذخیره‌سازی" [0.45, 0.8] (buy)
    "کاربر" -> "راوی"
    "راوی" -> "ذخیره‌سازی"
    evolve "راوی" 0.72`},{id:`cynefin`,category:`ایده`,title:`چارچوب کینِفین`,description:`جای‌گذاری موقعیت‌ها در دامنه‌های مختلف تصمیم‌گیری.`,docsUrl:`https://mermaid.js.org/syntax/cynefin.html`,code:`---
config:
  cynefin:
    showDomainDescriptions: true
---
cynefin-beta
    title تصمیم‌های محصول
    complex
      "کشف قابلیت تازه"
    complicated
      "بهینه‌سازی پایگاه داده"
    clear
      "انتشار نسخه"
    chaotic
      "قطعی سراسری"
    confusion
    complex --> complicated : "الگو شناخته شد"
    chaotic --> complex : "پایداری اولیه"`},{id:`treeview`,category:`مهندسی`,title:`نمای درختی`,description:`ساختار تو‌در‌توی پوشه‌ها، فایل‌ها یا هر سلسله‌مراتب.`,docsUrl:`https://mermaid.js.org/syntax/treeView.html`,code:`---
title: "ساختار پروژه"
config:
  treeView:
    showIcons: true
---
treeView-beta
  "پروژهٔ راوی"/
    "کد منبع"/
      "ویرایشگر.tsx" ## ویرایش متن
    "راهنما.md" ## راهنمای کاربر :::highlight`}],V={characters:4e4,lines:1e3,renderTimeoutMs:5e3},H=new Map,fe=80,U=0,W=Promise.resolve();function G(e){let t=2166136261;for(let n=0;n<e.length;n+=1)t^=e.charCodeAt(n),t=Math.imul(t,16777619);return(t>>>0).toString(36)}async function pe(e,t){if(!e||typeof Element>`u`)return t();let n=Element.prototype,r=Object.getOwnPropertyDescriptor(n,`toJSON`);try{return Object.defineProperty(n,`toJSON`,{configurable:!0,value(){return{tagName:this.tagName.toLocaleLowerCase(`en-US`),...this.id?{id:this.id}:{}}}}),await t()}finally{r?Object.defineProperty(n,`toJSON`,r):delete n.toJSON}}function K(e,t){return`${t}:${G(e)}`}function me(e,t){if(e instanceof O)return{kind:`syntax`,message:e.message,technical:e.message,suggestion:e.suggestion,line:e.line};let n=e instanceof Error?e.message:String(e||`Unknown error`),r=n.match(/line\s+(\d+)(?::(\d+))?/iu)??n.match(/(\d+):(\d+)/u),i=r?.[1]?Number(r[1]):void 0,a=r?.[2]?Number(r[2]):void 0,o=j(t),s=i?`ردیف ${i.toLocaleString(`fa-IR`)}${a?`، ستون ${a.toLocaleString(`fa-IR`)}`:``}`:`یکی از ردیف‌ها`,c=/Expecting\s+'COMMA'|got\s+'EOF'/iu.test(n)?`هر ردیف را به سه بخش مبدأ، مقصد و مقدار تقسیم کنید. راوی ویرگول فارسی را هم می‌پذیرد.`:/DQUOTE|ESCAPED_TEXT/iu.test(n)?`گیومهٔ باز و بستهٔ عنوان را بررسی کنید و برای متن‌های دارای ویرگول از گیومه استفاده کنید.`:/Lexical error|Unrecognized text|unexpected character/iu.test(n)?`نویسهٔ مشخص‌شده با ساختار این نوع نمودار سازگار نیست؛ نمونهٔ صحیح همان نوع را باز کنید.`:o===`sankey`?`هر مسیر سنکی باید سه بخش مبدأ، مقصد و مقدار داشته باشد.`:`ردیف مشخص‌شده را با نمونهٔ صحیح همان نوع مقایسه کنید.`;return{kind:`syntax`,message:`${s} قابل خواندن نیست.`,technical:n,line:i,column:a,suggestion:c}}function he(e){let t=e.split(/\r?\n/u).length;return e.length>V.characters?{kind:`limit`,message:`این نمودار برای رندر امن بیش از اندازه بزرگ است.`,technical:`حداکثر ${V.characters} نویسه مجاز است.`}:t>V.lines?{kind:`limit`,message:`تعداد خط‌های نمودار از سقف امن بیشتر است.`,technical:`حداکثر ${V.lines} خط مجاز است.`}:null}var ge={flowchart:`نمودار فرایند`,sequence:`نمودار توالی`,class:`نمودار کلاس`,state:`نمودار حالت`,er:`نمودار رابطهٔ موجودیت`,requirement:`نمودار نیازمندی`,architecture:`نمودار معماری`,c4:`نمودار زمینهٔ سامانه`,mindmap:`نقشهٔ ذهنی`,timeline:`خط زمانی`,kanban:`نمودار کانبان`,gitgraph:`نمودار شاخه‌های Git`,pie:`نمودار دایره‌ای`,sankey:`نمودار جریان سنکی`,journey:`نمودار سفر کاربر`,quadrant:`نمودار چهارخانه`,xychart:`نمودار XY`,gantt:`نمودار گانت`,swimlane:`نمودار مسیر مسئولیت`,block:`نمودار بلوکی`,packet:`نمودار ساختار بسته`,radar:`نمودار رادار`,eventmodeling:`نمودار مدل‌سازی رویداد`,treemap:`نقشهٔ درختی مساحتی`,venn:`نمودار ون`,ishikawa:`نمودار علت و معلول`,wardley:`نقشهٔ واردلی`,cynefin:`چارچوب کینفین`,treeview:`نمای درختی`,other:`نمودار Mermaid`};function _e(e,t){return(e.match(/^\s*accTitle\s*:\s*(.+)$/imu)?.[1]??e.match(/^\s*title\s+"?([^"\r\n]+)"?\s*$/imu)?.[1])?.trim().slice(0,160)||ge[t]}function ve(e,t={}){let n=new DOMParser,r=n.parseFromString(e,`image/svg+xml`),i=r.documentElement;if(r.querySelector(`parsererror`)){let t=n.parseFromString(e,`text/html`),a=t.querySelector(`svg`);if(!a)throw Error(`خروجی SVG قابل پردازش نبود.`);r=t,i=a}if(r.querySelectorAll(`script, iframe, object, embed, audio, video, image, img`).forEach(e=>e.remove()),r.querySelectorAll(`*`).forEach(e=>{for(let t of Array.from(e.attributes)){let n=t.name.toLocaleLowerCase(`en-US`),r=t.value.trim();if(n.startsWith(`on`)){e.removeAttribute(t.name);continue}if(n===`href`||n===`xlink:href`||n===`src`||n===`style`){let i=e.localName===`use`&&(n===`href`||n===`xlink:href`)&&/^#[A-Za-z_][\w:.-]*$/u.test(r);(/(?:javascript:|data:|https?:|file:|\/\/)/iu.test(r)||n===`src`||(n===`href`||n===`xlink:href`)&&!i)&&e.removeAttribute(t.name)}}}),t.labelMap?.size){let e=Array.from(t.labelMap.entries()).sort(([e],[t])=>t.length-e.length);r.querySelectorAll(`text, tspan`).forEach(t=>{if(t.children.length>0)return;let n=t.textContent?.trim();if(!n)return;let r=e.reduce((e,[t,n])=>e.replaceAll(t,n),n).replace(/[0-9]/gu,e=>`۰۱۲۳۴۵۶۷۸۹`[Number(e)]??e);r!==n&&(t.textContent=r)})}let a=Array.from(i.children).find(e=>e.localName===`title`),o=t.title?.trim()||a?.textContent?.trim();if(!a&&o){let e=r.createElementNS(`http://www.w3.org/2000/svg`,`title`);e.textContent=o,i.insertBefore(e,i.firstChild)}return i.setAttribute(`role`,`img`),o&&i.setAttribute(`aria-label`,o),i.setAttribute(`focusable`,`false`),i.setAttribute(`preserveAspectRatio`,`xMidYMid meet`),i.removeAttribute(`height`),i.removeAttribute(`width`),i.setAttribute(`style`,`max-width:100%;height:auto;font-family:IRANSansX,IRANSans,Vazirmatn,Tahoma,Arial,sans-serif;`),new XMLSerializer().serializeToString(i)}async function ye(e,t){let n=R(e),i=(await r(()=>import(`./mermaid.core-Ed2OIIdW.js`),__vite__mapDeps([0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22]))).default;i.initialize({startOnLoad:!1,securityLevel:`strict`,theme:t===`dark`?`dark`:`default`,fontFamily:`IRANSansX, IRANSans, Vazirmatn, Tahoma, Arial, sans-serif`,htmlLabels:!1,suppressErrorRendering:!0,deterministicIds:!0,deterministicIDSeed:G(`${t}:${n.code}`),flowchart:{htmlLabels:!1,useMaxWidth:!0}}),await i.parse(n.code,{suppressErrors:!1}),U+=1;let{svg:a}=await pe(n.kind===`block`,()=>i.render(`raavi-mermaid-${G(e)}-${U}`,n.code));return ve(a,{title:_e(e,n.kind),labelMap:n.labelMap})}async function be(e,t){let n=he(e);if(n)return{ok:!1,error:n};let r=K(e,t),i=H.get(r);if(i)return{ok:!0,svg:i,fromCache:!0};let a=()=>{},o=()=>{},s=new Promise((e,t)=>{a=e,o=t});W=W.then(async()=>{let n;try{n=setTimeout(()=>o(Error(`RAAVI_MERMAID_RENDER_TIMEOUT`)),V.renderTimeoutMs);let r=await ye(e,t);a(r)}catch(e){o(e)}finally{n&&clearTimeout(n)}}).then(()=>void 0,()=>void 0);try{let e=await s;if(H.size>=fe){let e=H.keys().next().value;e&&H.delete(e)}return H.set(r,e),{ok:!0,svg:e,fromCache:!1}}catch(t){return t instanceof Error&&t.message===`RAAVI_MERMAID_RENDER_TIMEOUT`?{ok:!1,error:{kind:`timeout`,message:`رندر نمودار بیش از حد طول کشید و متوقف شد.`,technical:`مهلت رندر ${V.renderTimeoutMs} میلی‌ثانیه است.`}}:{ok:!1,error:me(t,e)}}}var xe={status:`idle`,svg:``,lastValidSvg:``,renderKey:``,error:null},Se=80,q=new Map;function J(e,t){let n=K(e,t),r=q.get(n);return r?{status:`valid`,svg:r,lastValidSvg:r,renderKey:n,error:null}:xe}function Ce(e,t){if(q.delete(e),q.set(e,t),q.size<=Se)return;let n=q.keys().next().value;typeof n==`string`&&q.delete(n)}function we(e,t,n=0,r=0,a=!0){let[o,s]=(0,i.useState)(()=>J(e,t)),c=(0,i.useRef)(0);return(0,i.useEffect)(()=>{let i=c.current+1;if(c.current=i,!a){let n=window.setTimeout(()=>{c.current===i&&s(J(e,t))},0);return()=>window.clearTimeout(n)}let o=window.setTimeout(()=>{if(!e.trim()){s(e=>({...e,status:`invalid`,error:{kind:`syntax`,message:`برای دیدن پیش‌نمایش، کد Mermaid را وارد کنید.`,technical:`Empty Mermaid source`}}));return}let n=K(e,t),a=q.get(n);if(a&&r===0){s(e=>e.status===`valid`&&e.svg===a&&e.renderKey===n?e:{status:`valid`,svg:a,lastValidSvg:a,renderKey:n,error:null});return}s(e=>({...e,status:`loading`,error:null})),be(e,t).then(n=>{if(c.current===i){if(n.ok){let r=K(e,t);Ce(r,n.svg),s({status:`valid`,svg:n.svg,lastValidSvg:n.svg,renderKey:r,error:null});return}s(e=>({...e,status:`invalid`,svg:``,error:n.error}))}})},n);return()=>window.clearTimeout(o)},[e,n,a,r,t]),o}var Te=.05,Ee=4,Y={scale:1,x:0,y:0};function X(e){return Math.max(Te,Math.min(Ee,e))}function De({availableWidth:e,availableHeight:t,contentWidth:n,contentHeight:r}){return e<=0||t<=0||n<=0||r<=0?1:X(Math.min(1,e/n,t/r))}function Oe({enabled:e=!0}={}){let[t,n]=(0,i.useState)(Y),[r,a]=(0,i.useState)(!1),o=(0,i.useRef)(t),s=(0,i.useRef)(null),c=(0,i.useCallback)(e=>{n(t=>{let n=typeof e==`function`?e(t):e;return o.current=n,n})},[]),l=(0,i.useCallback)(()=>{s.current=null,a(!1),c(Y)},[c]),u=(0,i.useCallback)((e,t)=>{if(!e||!t){l();return}let n=window.getComputedStyle(e),r=Number.parseFloat(n.paddingInlineStart)+Number.parseFloat(n.paddingInlineEnd),i=Number.parseFloat(n.paddingTop)+Number.parseFloat(n.paddingBottom),u=De({availableWidth:e.clientWidth-r,availableHeight:e.clientHeight-i,contentWidth:t.offsetWidth,contentHeight:t.offsetHeight}),d=e.getBoundingClientRect(),f=t.getBoundingClientRect(),p=Number.parseFloat(n.paddingInlineStart),m=Number.parseFloat(n.paddingTop),h=e.clientWidth-r,g=e.clientHeight-i,_={x:d.left+e.clientLeft+p+h/2,y:d.top+e.clientTop+m+g/2},v=o.current,y=t.offsetParent===e?{x:d.left+e.clientLeft+t.offsetLeft+t.offsetWidth/2,y:d.top+e.clientTop+t.offsetTop+t.offsetHeight/2}:{x:f.left+f.width/2-v.x,y:f.top+f.height/2-v.y};s.current=null,a(!1),c({scale:u,x:_.x-y.x,y:_.y-y.y})},[l,c]),d=(0,i.useCallback)((e,t)=>{c(n=>{let r=X(e);if(r===n.scale)return n;if(!t)return{...n,scale:r};let i=r/n.scale;return{scale:r,x:t.x-(t.x-n.x)*i,y:t.y-(t.y-n.y)*i}})},[c]),f=(0,i.useCallback)(e=>{d(o.current.scale+e)},[d]),p=(0,i.useCallback)(t=>{if(!e)return;t.preventDefault();let n=t.currentTarget.getBoundingClientRect(),r={x:t.clientX-n.left-n.width/2,y:t.clientY-n.top-n.height/2},i=Math.exp(-t.deltaY*.0015);d(o.current.scale*i,r)},[e,d]),m=(0,i.useCallback)(t=>{if(!e||t.button!==0||!t.isPrimary||t.target instanceof Element&&t.target.closest(`button, a, input, textarea, select`))return;t.preventDefault();let n=o.current;s.current={pointerId:t.pointerId,clientX:t.clientX,clientY:t.clientY,originX:n.x,originY:n.y},t.currentTarget.setPointerCapture(t.pointerId),a(!0)},[e]),h=(0,i.useCallback)(e=>{let t=s.current;!t||t.pointerId!==e.pointerId||(e.preventDefault(),c(n=>({...n,x:t.originX+e.clientX-t.clientX,y:t.originY+e.clientY-t.clientY})))},[c]),g=(0,i.useCallback)(e=>{s.current?.pointerId===e.pointerId&&(s.current=null,a(!1),e.currentTarget.hasPointerCapture(e.pointerId)&&e.currentTarget.releasePointerCapture(e.pointerId))},[]);return{scale:t.scale,scalePercent:Math.round(t.scale*100),transform:`translate(${t.x}px, ${t.y}px) scale(${t.scale})`,panning:r,zoomBy:f,resetView:l,fitView:u,viewportHandlers:{onWheel:p,onPointerDown:m,onPointerMove:h,onPointerUp:g,onPointerCancel:g,onLostPointerCapture:g}}}var Z=n();function ke(){let[e,t]=(0,i.useState)([]),n=(0,i.useCallback)((e,n)=>{t(t=>{let r=t.includes(e);return n&&!r?[...t,e]:!n&&r?t.filter(t=>t!==e):t})},[]);return(0,i.useMemo)(()=>({stack:e,topLayer:e.at(-1)??null,syncLayer:n}),[e,n])}function Q(e){return Array.from(e.querySelectorAll([`button:not([disabled])`,`input:not([disabled])`,`textarea:not([disabled])`,`select:not([disabled])`,`[href]`,`[tabindex]:not([tabindex="-1"])`].join(`,`))).filter(e=>e.offsetParent!==null&&e.getAttribute(`aria-hidden`)!==`true`)}function $({open:e,isTopLayer:t,containerRef:n,initialFocusRef:r,returnFocusRef:a}){let o=(0,i.useRef)(null);(0,i.useEffect)(()=>{if(!e)return;let t=a?.current??null;return o.current=t??(document.activeElement instanceof HTMLElement?document.activeElement:null),()=>{let e=t??o.current;e?.isConnected&&requestAnimationFrame(()=>e.focus())}},[e,a]),(0,i.useEffect)(()=>{if(!e||!t)return;let i=n.current;if(!i)return;let a=()=>{let e=r?.current;(e&&i.contains(e)?e:Q(i)[0]??i).focus()};requestAnimationFrame(a);let o=e=>{if(e.key!==`Tab`)return;let t=Q(i);if(!t.length){e.preventDefault(),i.focus();return}let n=t[0],r=t[t.length-1];e.shiftKey&&document.activeElement===n?(e.preventDefault(),r.focus()):!e.shiftKey&&document.activeElement===r&&(e.preventDefault(),n.focus())},s=e=>{e.target instanceof Node&&!i.contains(e.target)&&a()};return document.addEventListener(`keydown`,o),document.addEventListener(`focusin`,s),()=>{document.removeEventListener(`keydown`,o),document.removeEventListener(`focusin`,s)}},[n,r,t,e])}function Ae({open:e,isTopLayer:t,onClose:n,dialogRef:r,initialFocusRef:i,returnFocusRef:a,backdropClassName:o,dialogClassName:s,labelledBy:c,describedBy:l,children:u}){return $({open:e,isTopLayer:t,containerRef:r,initialFocusRef:i,returnFocusRef:a}),e?(0,Z.jsx)(`div`,{className:o,role:`presentation`,onMouseDown:e=>{t&&e.target===e.currentTarget&&n()},children:(0,Z.jsx)(`div`,{ref:r,className:s,role:`dialog`,"aria-modal":`true`,"aria-labelledby":c,"aria-describedby":l,tabIndex:-1,children:u})}):null}export{v as A,C,te as D,b as E,g as M,h as N,ee as O,m as P,ne as S,x as T,oe as _,we as a,ie as b,j as c,k as d,ce as f,T as g,E as h,Oe as i,_ as j,y as k,A as l,D as m,$ as n,z as o,se as p,ke as r,B as s,Ae as t,M as u,w as v,S as w,re as x,ae as y};